All contributions are welcome, this is a community-driven project, created and open-sourced for the sake of fun and knowledge.

We'll adhere to "PHP Framework Interoperability Group" [accepted coding standards](https://github.com/php-fig/fig-standards/tree/master/accepted).

You can use Sensio Labs' [PHP Coding Standards Fixer](http://cs.sensiolabs.org/) to convert your current codebase (we'll convert ours, eventually).

Unit tests are coming as well to tackle the common issues regarding PHP itself (missing modules, etc).

*Last update: Sep 18, 2012*
